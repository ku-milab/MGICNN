View this README fild in RAW mode.

Download BRATS 2015 dataset.
Move HGG(train), LGG(train), HGG_LGG(test) folder into a directory called "input".
Create a directory called "GT" in the same directory where you have created "input" folder
-somedirectory
  -GT
  -input
    -HGG
    -LGG
    -HGG_LGG


1. remove txt
for n in ./*/*/*/*.txt; do rm "$n"; done

2. move to parent
for n in ./*/*/*/*; do mv "$n" "$(dirname "$(dirname "$n")")"; done

3. remove excess directories
for n in ./*/*/*/; do rm -r "$n"; done

4. rename all directoriies
a=1
cd HGG
for n in *; do  mv "$n" "h.$a";  let a=a+1; done
a=1
cd ../LGG
for n in *; do  mv "$n" "l.$a";  let a=a+1; done
a=1
cd ../HGG_LGG
for n in *; do  mv "$n" "t.$a";  let a=a+1; done

5. Rename all files
for n in */*.mha; do  new="$(echo "$n" |  sed 's/\//./')"; mv "$n" "$new"; done
cd ../HGG
for n in */*.mha; do  new="$(echo "$n" |  sed 's/\//./')"; mv "$n" "$new"; done
cd ../HGG_LGG
for n in */*.mha; do  new="$(echo "$n" |  sed 's/\//./')"; mv "$n" "$new"; done

6. Remove all directories
cd ..
for n in */*/; do  rm -r "$n"; done

7. Move all to one directory
for n in ./*/*; do mv "$n" "$(dirname "$(dirname "$n")")"; done

///////////////////
Convert MHA to NIFTI format
Takes about 2.5 hours
1. Process GT
seperate OT from train data to another folder.
cd GT
for n in *.mha; do   /home/wltjr1007/PycharmProjects/CNNforBRATS/c3d/bin/c3d "./$n" -type uchar /media/wltjr1007/hdd1/personal/brats/data/"${n%.mha}.nii"; done

2. N4ITK and convert
cd ../input
for n in *.mha; do   /home/wltjr1007/PycharmProjects/CNNforBRATS/slicer/lib/Slicer-4.5/cli-modules/N4ITKBiasFieldCorrection "./$n" /media/wltjr1007/hdd1/personal/brats/data/"${n%.mha}.nii"; done

////////////////
Convert Nifti to MHA
for n in *.nii; do   /home/wltjr1007/PycharmProjects/CNNforBRATS/c3d/bin/c3d "./$n" -type uchar "${n%.nii}.mha"; done
