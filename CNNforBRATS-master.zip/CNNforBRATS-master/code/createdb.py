from __future__ import print_function

import os
import pickle
import time
from datetime import datetime

import numpy as np
from medpy.filter import IntensityRangeStandardization
from medpy.io import load

from code import train

# from code import test

WITHOUT_IRS = False
IS_TEST = False
SHAPE = (4, 240, 240, 155)
KERNEL = (33, 33)
SAMPLECNT = [[550000, 0.6], [550000, 0.5]]
CLASSCNT = 5
MODCNT = 4
ROTATE = 1

# opts, args = getopt.getopt(sys.argv[1:], "rw", ["read=", "write="])
# for opt, arg in opts:
#    if opt in ("-r", "--read"):
#        READ_PATH = arg
#    elif opt in ("-w", "--write"):
#        WRITE_PATH = arg
# if len(READ_PATH) == 0:
DATA_READ_PATH = "/home/wltjr1007/PycharmProjects/CNNforBRATS/traindata/"
TEST_READ_PATH = "/home/wltjr1007/PycharmProjects/CNNforBRATS/testdata/"
ORIG_READ_PATH = "/media/wltjr1007/hdd1/personal/brats/data/"
HDD_WRITE_PATH = "/media/wltjr1007/hdd1/personal/brats/output_old/"
SSD_WRITE_PATH = "/home/wltjr1007/PycharmProjects/CNNforBRATS/output_old/"

hl = {'h': 0, 'l': 1, 't': 2, 'hl': 3}
MODS = {"T1": 0, "T2": 1, "T1c": 2, "Flair": 3, "OT": 4}


def get_img_name_list(path):  # h.7.VSD.Brain_3more.XX.O.OT.54553.nii
    name_list = os.listdir(path)
    result_list_l = {}
    result_list_h = {}
    result_list_t = {}
    for name in name_list:
        temp = name.replace(".nii", "").split(".")
        dataset = temp[0]
        cnt = int(temp[1]) - 1
        mod = MODS[temp[-2].split("_")[-1]]
        if dataset == "l":
            result_list_l[cnt, mod] = name
        elif dataset == "h":
            result_list_h[cnt, mod] = name
        elif dataset == "t":
            result_list_t[cnt, mod] = name
    return np.array([result_list_h, result_list_l, result_list_t])


def get_img(PATH, name, isOT=False):
    # return load(PATH + name)[0]
    result = load(PATH + name)[0]
    if not isOT:
        minpxl = np.min(result)
        if minpxl < 0:
            result[result != 0] -= minpxl
            # result *=(36058/np.max(result))
    return result


def trainIRS(data_list, dataset):
    logthis("Train LGG IRS Started")
    irs = IntensityRangeStandardization()
    imgcnt = len(data_list[hl[dataset]]) // 5
    if not WITHOUT_IRS:
        for i in range(imgcnt):
            for mod in range(MODCNT):
                curimg = get_img(ORIG_READ_PATH, data_list[hl[dataset]][i, mod])
                import matplotlib.pyplot as plt
                plt.imshow(curimg[:, :, 70], cmap="gray")
                plt.show()
                irs = irs.train([curimg[curimg > 0]])
            print("\rIRS Train", i + 1, "/", imgcnt, end="")
        with open(os.path.join(HDD_WRITE_PATH, "intensitymodel.txt"), 'wb') as f:
            pickle.dump(irs, f)


def getlabel(data_list, datasetclass):
    logthis(datasetclass + " Getting label started.")
    TOTAL = np.sum([len(data_list[hl[dataset]]) for dataset in datasetclass]) // 5
    label = np.memmap(filename=os.path.join(HDD_WRITE_PATH, datasetclass + "_gt.dat"), mode="r+",
                      shape=(TOTAL, SHAPE[1], SHAPE[2], SHAPE[3]), dtype=np.int8)
    cnt = 0
    for dataset in datasetclass:
        set_size = len(data_list[hl[dataset]]) // 5
        for i in range(set_size):
            label[cnt] = get_img(ORIG_READ_PATH, data_list[hl[dataset]][i, MODS["OT"]], True)
            cnt += 1
            print("\rLabel", datasetclass, i + 1, "/", set_size, end="")
    return label


def read_from_file(data_list, datasetclass):
    logthis(datasetclass + " Reading training dataset & IRS trainig started")

    fp = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_orig.dat"), dtype=np.float32, mode="r+", shape=(
        np.sum([len(data_list[hl[dataset]]) for dataset in datasetclass]) // 5, SHAPE[0], SHAPE[1], SHAPE[2], SHAPE[3]))
    labels = np.memmap(filename=os.path.join(HDD_WRITE_PATH, datasetclass + "_gt.dat"), mode="r",
                       shape=(fp.shape[0], SHAPE[1], SHAPE[2], SHAPE[3]), dtype=np.int8)
    cnt = 0
    with open(os.path.join(HDD_WRITE_PATH, "intensitymodel.txt"), 'r') as f:
        trained_model = pickle.load(f)
    labelid = {}
    labelid2 = {}
    # CUT_SIZE = [409, 525, 409, 416, 424] --> rotate equal all
    # CUT_SIZE = [1635,2751,1636,1729,1775] --> equal all
    # CUT_SIZE = [1022,312,256,258,263] --> rotate .5
    CUT_SIZE = np.array([9091, 4359, 2273, 2450, 2489])  # --> 0.5
    DIM_MOVE = np.array([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]])
    DIM_MOVE_CNT = 0.2
    for dataset in datasetclass:
        set_size = len(data_list[hl[dataset]]) // 5
        for i in range(set_size):
            for mod in range(MODCNT):
                curimg = get_img(ORIG_READ_PATH, data_list[hl[dataset]][i, mod])

                if mod == 0:
                    for clscnt in range(CLASSCNT):
                        labelidx = np.argwhere(labels[cnt] == clscnt).astype(np.uint8).copy()
                        if labelidx.shape[0] == 0:
                            labelid[cnt, clscnt] = np.empty((0, 3))
                            labelid2[cnt, clscnt] = np.empty((0, 3))
                            continue
                        if clscnt == 0:
                            dataidx = np.argwhere(curimg != 0)
                            cumdims = (np.maximum(labelidx.max(), dataidx.max()) + 1) ** np.arange(dataidx.shape[1])
                            labelidx = labelidx[np.in1d(labelidx.dot(cumdims), dataidx.dot(cumdims))]

                            dataidx = np.argwhere(labels[cnt] != 0)
                            closeidx = np.zeros((0, 3), dtype=np.uint8)
                            for j in range(DIM_MOVE.shape[0]):
                                cumdims = (np.maximum(labelidx.max(), (dataidx + DIM_MOVE[j]).max()) + 1) ** np.arange(
                                    (dataidx + DIM_MOVE[j]).shape[1])
                                closeidx = np.append(closeidx, labelidx[
                                    np.in1d(labelidx.dot(cumdims), (dataidx + DIM_MOVE[j]).dot(cumdims))], axis=0)

                            a = np.ascontiguousarray(closeidx)
                            unique_a = np.unique(a.view([('', a.dtype)] * a.shape[1]))
                            closeidx = unique_a.view(a.dtype).reshape((unique_a.shape[0], a.shape[1]))

                            cumdims = (np.maximum(labelidx.max(), closeidx.max()) + 1) ** np.arange(closeidx.shape[1])
                            labelidx = labelidx[~np.in1d(labelidx.dot(cumdims), closeidx.dot(cumdims))]

                            labelidx = np.sort(labelidx.view("u1,u1,u1"), order=["f2"], axis=0).view(np.uint8)
                            labelidx = labelidx[np.linspace(start=0, stop=labelidx.shape[0], num=min(
                                int(CUT_SIZE[clscnt] * (1 - DIM_MOVE_CNT)), labelidx.shape[0]), endpoint=False,
                                                            dtype=np.uint32)]
                            closeidx = np.sort(closeidx.view("u1,u1,u1"), order=["f2"], axis=0).view(np.uint8)
                            closeidx = closeidx[np.linspace(start=0, stop=closeidx.shape[0], num=min(
                                int(CUT_SIZE[clscnt] * DIM_MOVE_CNT), closeidx.shape[0]), endpoint=False,
                                                            dtype=np.uint32)]
                            labelid[cnt, clscnt] = np.random.permutation(
                                np.append(labelidx[::2], closeidx[::2], axis=0)).astype(np.uint8)
                            labelid2[cnt, clscnt] = np.random.permutation(
                                np.append(labelidx[1::2], closeidx[1::2], axis=0)).astype(np.uint8)


                        else:
                            labelidx = np.sort(labelidx.view("u1,u1,u1"), order=["f2"], axis=0).view(np.uint8)
                            labelidx = labelidx[np.linspace(start=0, stop=labelidx.shape[0],
                                                            num=min(CUT_SIZE[clscnt], labelidx.shape[0]),
                                                            endpoint=False, dtype=np.uint32)]
                            labelid[cnt, clscnt] = np.random.permutation(labelidx[::2]).astype(np.uint8)
                            labelid2[cnt, clscnt] = np.random.permutation(labelidx[1::2]).astype(np.uint8)
                curimg[curimg > 0] = trained_model.transform(curimg[curimg > 0], surpress_mapping_check=True)
                fp[cnt, mod] = curimg
            cnt += 1
            print("\r" + dataset, "Image Get", i + 1, "/", set_size, end="")

    with open(os.path.join(HDD_WRITE_PATH, "labelidx.txt"), 'wb') as f:
        pickle.dump(labelid, f)
    with open(os.path.join(HDD_WRITE_PATH, "labelidx2.txt"), 'wb') as f:
        pickle.dump(labelid2, f)

    print("")
    return fp


def get_mean_var(fp, data_list, datasetclass):
    if fp is None:
        fp = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_orig.dat"), dtype=np.float32, mode="r", shape=(
            np.sum([len(data_list[hl[dataset]]) for dataset in datasetclass]) // 5, SHAPE[0], SHAPE[1], SHAPE[2],
            SHAPE[3]))

    allstd = np.zeros(SHAPE[0], dtype=np.float32)
    for i in range(SHAPE[0]):
        allstd[i] = np.std(fp[:, i, :, :, :])
    allmean = np.mean(fp, axis=(0, 2, 3, 4))
    np.save(os.path.join(HDD_WRITE_PATH, datasetclass + "_zmuv.npy"), np.array([allmean, allstd]))


def temp_get_label(data_list, datasetclass):
    labelid = {}
    CUT_SIZE = [1600, 525, 409, 416, 424]

    fp = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_orig.dat"), dtype=np.float32, mode="r", shape=(
        np.sum([len(data_list[hl[dataset]]) for dataset in datasetclass]) // 5, SHAPE[0], SHAPE[1], SHAPE[2], SHAPE[3]))
    labels = np.memmap(filename=os.path.join(HDD_WRITE_PATH, datasetclass + "_gt.dat"), mode="r",
                       shape=(fp.shape[0], SHAPE[1], SHAPE[2], SHAPE[3]), dtype=np.int8)
    cnt = 0
    for curimg, curlabel in zip(fp[:, 0, :, :, :], labels):
        dataidx = np.argwhere(curimg == 0).astype(np.uint8)
        for clscnt in range(CLASSCNT):
            labelidx = np.argwhere(curlabel == clscnt).astype(np.uint8)
            if labelidx.shape[0] == 0:
                labelid[cnt, clscnt] = np.empty((0, 3))
                continue
            cumdims = (np.maximum(labelidx.max(), dataidx.max()) + 1) ** np.arange(dataidx.shape[1])
            labelid[cnt, clscnt] = np.random.permutation(
                labelidx[~np.in1d(labelidx.dot(cumdims), dataidx.dot(cumdims))])[:CUT_SIZE[clscnt]].astype(
                np.uint8)
        cnt += 1

    with open(os.path.join(HDD_WRITE_PATH, "labelidx.txt"), 'wb') as f:
        pickle.dump(labelid, f)


def finalize_input(datas, labels, data_list, datasetclass):
    logthis(datasetclass + " Finalizing input started.")
    TOTAL = np.sum([len(data_list[hl[dataset]]) for dataset in datasetclass]) // 5
    if datas is None:
        datas = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_orig.dat"), dtype=np.float32,
                          shape=(TOTAL, SHAPE[0], SHAPE[1], SHAPE[2], SHAPE[3]), mode="r")
    if labels is None:
        labels = np.memmap(filename=os.path.join(HDD_WRITE_PATH, datasetclass + "_gt.dat"),
                           shape=(TOTAL, SHAPE[1], SHAPE[2], SHAPE[3]), dtype=np.int8, mode="r")
    print(datasetclass + " started")

    with open(os.path.join(HDD_WRITE_PATH, "labelidx.txt"), 'r') as f:
        labelid = pickle.load(f)
    with open(os.path.join(HDD_WRITE_PATH, "labelidx2.txt"), 'r') as f:
        labelid2 = pickle.load(f)
    sample_size = np.sum([value.shape[0] for _, value in labelid.items()])
    sample_size2 = np.sum([value.shape[0] for _, value in labelid2.items()])
    fdata = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_train.dat"), dtype=np.float32,
                      shape=(sample_size * ROTATE, KERNEL[0], KERNEL[1], SHAPE[0]), mode="w+")
    flabel = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_train.lbl"), dtype=np.int8,
                       shape=(fdata.shape[0]), mode="w+")
    fdata_2 = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_train_2.dat"), dtype=np.float32,
                        shape=(
                        sample_size2 * ROTATE, KERNEL[0] + 2 * (KERNEL[0] // 2), KERNEL[1] + 2 * (KERNEL[1] // 2),
                        SHAPE[0]), mode="r+")
    flabel_2 = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_train_2.lbl"), dtype=np.int8,
                         shape=(fdata_2.shape[0]), mode="r+")
    # flabel_2_no_need = np.memmap(os.path.join(HDD_WRITE_PATH, datasetclass + "_train_2.lbl"), dtype=np.int8,
    #                      shape=(fdata_2.shape[0], KERNEL[0], KERNEL[1]), mode="r+")

    cnt = 0
    cnt2 = 0
    cnt3 = 0
    for data, label in zip(datas, labels):
        zzz = time.time()
        for clscnt in range(CLASSCNT):
            for curid in range(labelid[cnt2, clscnt].shape[0]):
                randid = labelid[cnt2, clscnt][curid]
                WH = [randid[0] - KERNEL[0] / 2, randid[0] + KERNEL[0] / 2 + 1, randid[1] - KERNEL[1] / 2,
                      randid[1] + KERNEL[1] / 2 + 1]
                tempdata = np.rollaxis(np.nan_to_num(data[:, WH[0]:WH[1], WH[2]:WH[3], randid[2]]), 0, 3)
                for rot in range(ROTATE):
                    fdata[cnt] = np.rot90(tempdata, rot)
                    flabel[cnt] = clscnt
                    cnt += 1
            for curid in range(labelid2[cnt2, clscnt].shape[0]):
                randid = labelid2[cnt2, clscnt][curid]
                WH_2 = [randid[0] - 2 * (KERNEL[0] // 2), randid[0] + 2 * (KERNEL[0] // 2) + 1,
                        randid[1] - 2 * (KERNEL[1] // 2),
                        randid[1] + 2 * (KERNEL[1] // 2) + 1]
                tempdata_2 = data[:, WH_2[0]:WH_2[1], WH_2[2]:WH_2[3], randid[2]]
                pad = [min(fdata_2.shape[1] / 2, max(0, -WH_2[0])),
                       min(fdata_2.shape[1] / 2, max(0, WH_2[1] - SHAPE[1])),
                       min(fdata_2.shape[2] / 2, max(0, -WH_2[2])),
                       min(fdata_2.shape[2] / 2, max(0, WH_2[3] - SHAPE[2]))]
                if tempdata_2.shape != (SHAPE[0], fdata_2.shape[1], fdata_2.shape[2]):
                    tempdata_2 = np.pad(tempdata_2, ((0, 0), (pad[0:2]), (pad[2:4])), "constant")
                tempdata_2 = np.rollaxis(np.nan_to_num(tempdata_2), 0, 3)
                for rot in range(ROTATE):
                    fdata_2[cnt3] = np.rot90(tempdata_2, rot)
                    flabel_2[cnt3] = clscnt
                    cnt3 += 1

        cnt2 += 1
        print("\rWrite data", cnt2, "/", TOTAL, time.time() - zzz, end="")
    return fdata


def get_test_data(data_list):
    logthis("Test dataset started.")
    fp = np.memmap(os.path.join(HDD_WRITE_PATH, "t_orig.dat"), dtype=np.float32, mode="w+",
                   shape=(len(data_list[hl["t"]]) // 4, SHAPE[0], SHAPE[1], SHAPE[2], SHAPE[3]))
    set_size = fp.shape[0]
    with open(os.path.join(HDD_WRITE_PATH, "intensitymodel.txt"), 'r') as f:
        trained_model = pickle.load(f)
    for i in range(set_size):
        for mod in range(MODCNT):
            curimg = get_img(ORIG_READ_PATH, data_list[hl["t"]][i, mod])

            curimg[curimg > 0] = trained_model.transform(curimg[curimg > 0], surpress_mapping_check=True)
            fp[i, mod] = curimg
        print("\rTest data", i + 1, "/", set_size, end="")


def gauss_norm(fdata, tdata, datasetclass):
    logthis(datasetclass + " Gauss Normalization Started.")
    if fdata is None:
        # os.system("cp " + os.path.join(SSD_WRITE_PATH, datasetclass+"_train2.dat") + " " + os.path.join(SSD_WRITE_PATH,
        #                                                                                                   datasetclass+"_train.dat"))
        fdata = np.memmap(os.path.join(SSD_WRITE_PATH, datasetclass + "_train.dat"), dtype=np.float32,
                          mode="r+").reshape((-1, KERNEL[0], KERNEL[1], SHAPE[0]))
    # if tdata is None:
    #     os.system(
    #         "cp " + os.path.join(HDD_WRITE_PATH, "test_orig.dat") + " " + os.path.join(SSD_WRITE_PATH, "test_orig.dat"))
    #     tdata = np.memmap(os.path.join(SSD_WRITE_PATH, "test_orig.dat"), dtype=np.float32, mode="r+").reshape(
    #         (-1, SHAPE[1], SHAPE[2], SHAPE[3], SHAPE[0]))
    #
    # allmean = np.mean(fdata)
    # print("\nMean", allmean)
    #
    # sumall = 0.
    # for curdata in fdata:
    #     sumall += np.sum(np.square(np.subtract(curdata, allmean)))
    # allstd = np.sqrt(sumall / fdata.size)
    # print("Variance", allstd)

    allmean, allstd = np.load(os.path.join(HDD_WRITE_PATH, datasetclass + "_zmuv.npy"))
    for i in range(4):
        fdata[..., i] -= allmean[i]
        print(str(i) + " Train mean zero")
        fdata[..., i] /= allstd[i]
        print(str(i) + "Train unit variance")
        # tdata[...,i] -= allmean[i]
        # print(str(i)+"Test mean zero")
        # tdata[...,i]/=allstd[i]
        # print(str(i)+"Gaussian Normalized")


def logthis(a):
    print("\n" + str(datetime.now()) + ":", a)


def testaaa(data_list):
    with open(os.path.join(HDD_WRITE_PATH, "labelidx.txt"), 'r') as f:
        labelid = pickle.load(f)
    sample_size = np.sum([value.shape[0] for _, value in labelid.items()])
    fdata_2 = np.memmap(os.path.join(HDD_WRITE_PATH, "h_train_2.dat"), dtype=np.float32,
                        shape=(sample_size * ROTATE, KERNEL[0] + 2 * (KERNEL[0] // 2), KERNEL[1] + 2 * (KERNEL[1] // 2),
                               SHAPE[0]), mode="r")
    flabel_2 = np.memmap(os.path.join(HDD_WRITE_PATH, "h_train_2.lbl"), dtype=np.int8,
                         shape=(fdata_2.shape[0], KERNEL[0], KERNEL[1]), mode="r")
    print(fdata_2.shape)
    print(flabel_2.shape)
    # from medpy.io import save
    # with open(os.path.join(HDD_WRITE_PATH, "intensitymodel.txt"), 'r') as f:
    #     trained_model = pickle.load(f)
    # allmean, allstd = np.load(os.path.join(HDD_WRITE_PATH, "h_zmuv.npy"))
    # curimgidx = 47
    # # hdr = load("/media/wltjr1007/hdd1/personal/brats/GT/48_flair_n4itk.nii")[1]
    # for mod in range(4):
    #     MODNAME=list(MODS.keys())[list(MODS.values()).index(mod)]
    #     curimg = get_img(ORIG_READ_PATH, data_list[hl["h"]][curimgidx, mod])
    #     curimg[curimg > 0] = trained_model.transform(curimg[curimg > 0], surpress_mapping_check=True)
    #     # save(curimg, "/media/wltjr1007/hdd1/personal/brats/GT/"+str(curimgidx+1)+"_"+MODNAME.lower()+"_hist.nii", hdr)
    #     print(curimg[100,100:103,70:73])
    #     curimg-=allmean[mod]
    #     curimg/=allstd[mod]
    #     print(curimg[100,100:103,70:73])
    #     break
    #     # save(curimg, "/media/wltjr1007/hdd1/personal/brats/GT/"+str(curimgidx+1)+"_"+MODNAME.lower()+"_gauss.nii", hdr)

    # curimg,hdr = load("/media/wltjr1007/hdd1/personal/brats/48_flair_n4itk.nii")
    # curimg[curimg > 0] = trained_model.transform(curimg[curimg > 0], surpress_mapping_check=True)
    # save("/media/wltjr1007/hdd1/personal/brats/48_flair_hist.nii", hdr)
    # save("/media/wltjr1007/hdd1/personal/brats/48_flair_gauss.nii", hdr)
    # save("/media/wltjr1007/hdd1/personal/brats/48_t1_gauss.nii", hdr)
    # save("/media/wltjr1007/hdd1/personal/brats/48_t1c_gauss.nii", hdr)
    # save("/media/wltjr1007/hdd1/personal/brats/48_t2_gauss.nii", hdr)
    # for
    #
    # curimg,hdr = load("/media/wltjr1007/hdd1/personal/brats/48_t1_n4itk.nii")
    # curimg[curimg > 0] = trained_model.transform(curimg[curimg > 0], surpress_mapping_check=True)
    # save("/media/wltjr1007/hdd1/personal/brats/48_t1_hist.nii", hdr)
    #
    #
    # curimg,hdr = load("/media/wltjr1007/hdd1/personal/brats/48_t2_n4itk.nii")
    # curimg[curimg > 0] = trained_model.transform(curimg[curimg > 0], surpress_mapping_check=True)
    # save("/media/wltjr1007/hdd1/personal/brats/48_t2_hist.nii", hdr)
    #
    #
    # curimg,hdr = load("/media/wltjr1007/hdd1/personal/brats/48_t1c_n4itk.nii")
    # curimg[curimg > 0] = trained_model.transform(curimg[curimg > 0], surpress_mapping_check=True)
    # save("/media/wltjr1007/hdd1/personal/brats/48_t1c_hist.nii", hdr)


def start_preproces():
    # gauss_norm(h_patch, t_data, "h")
    data_name_list = get_img_name_list(ORIG_READ_PATH)
    # testaaa(data_name_list)
    h_data = None
    h_label = None
    h_patch = None
    t_data = None
    trainIRS(data_name_list, "h")
    # h_label = getlabel(data_name_list, "h")
    # h_data = read_from_file(data_name_list, "h")
    # get_mean_var(h_data,data_name_list,"h")
    h_patch = finalize_input(h_data, h_label, data_name_list, "h")
    # get_test_data(data_name_list)
    train.train_main("h")
    # train.extract_PM("t", mode=1, resume=89)
    # train.extract_PM_window("h",is_mean=None, patch_size=(33,33))
    # train.train_PM_CNN("h", mean_size=(0,0),patch_size=(33,33), is_inception=True)
    # train.test_PM_CNN("t", isMean=(0,0), test_set=np.array([1,58,77]), patch_size=(33,33), is_inception=True)
    print("Done!")


if __name__ == '__main__':
    start_preproces()
