import sys
import time

import cv2
import numpy as np
from PyQt4 import uic
from PyQt4.QtCore import *
from PyQt4.QtGui import *


def mean_field(loss_square_cd, loss_square_cr, label_map, q_prev):
    gamma = 0.9
    h = loss_square_cr.shape[0]
    w = loss_square_cd.shape[1]

    label_map_non_zero = label_map
    label_map_non_one = 1 - label_map
    label_map_non_zero[label_map_non_zero == 0] = sys.float_info.min
    label_map_non_one[label_map_non_one == 0] = sys.float_info.min

    loss_zero = np.zeros((h, w))
    loss_zero[0:h - 1, 0:w] += (1 - q_prev[0:h - 1, 0:w]) * loss_square_cd
    loss_zero[1:h, 0:w] += (1 - q_prev[1:h, 0:w]) * loss_square_cd
    loss_zero[0:h, 0:w - 1] += (1 - q_prev[0:h, 0:w - 1]) * loss_square_cr
    loss_zero[0:h, 1:w] += (1 - q_prev[0:h, 1:w]) * loss_square_cr

    loss_one = np.zeros((h, w))
    loss_one[0:h - 1, 0:w] += q_prev[0:h - 1, 0:w] * loss_square_cd
    loss_one[1:h, 0:w] += q_prev[1:h, 0:w] * loss_square_cd
    loss_one[0:h, 0:w - 1] += q_prev[0:h, 0:w - 1] * loss_square_cr
    loss_one[0:h, 1:w] += q_prev[0:h, 1:w] * loss_square_cr

    q_pos = np.log(label_map_non_zero) + loss_zero
    q_neg = np.log(label_map_non_one) + loss_one
    q_star = np.exp(q_pos) / (np.exp(q_pos) + np.exp(q_neg))
    q_curr = gamma * q_star + (1 - gamma) * q_prev

    return q_curr


form_class = uic.loadUiType("test_GUI_5.ui")[0]


class MyWindow(QMainWindow, form_class):
    def __init__(self):
        super(MyWindow, self).__init__()
        self.setupUi(self)
        self.connect(self.pushButton, SIGNAL("clicked()"), self.btn_clicked_1)
        self.connect(self.pushButton_3, SIGNAL("clicked()"), self.btn_clicked_3)
        self.c1 = None
        self.c2 = None
        self.cd = None
        self.cr = None
        self.lab_f = None
        self.more = None
        self.rep = 0

    def btn_clicked_1(self):
        self.fn = QFileDialog.getOpenFileName(self, 'image', QDir.currentPath())
        self.fn_sat = self.fn[:len(self.fn) - 8] + '_sat.png'
        self.fn_lab = self.fn[:len(self.fn) - 8] + '_lab.png'
        temp_sat = cv2.imread(str(self.fn_sat))
        temp_lab = cv2.imread(str(self.fn_lab))
        self.c1 = cv2.cvtColor(temp_sat, cv2.COLOR_BGR2RGB)
        self.c2 = (cv2.cvtColor(temp_lab, cv2.COLOR_BGR2RGB).astype('float') / 125 * 255).astype('uint8')
        self.c1_show = cv2.resize(self.c1, (300, 300))
        self.c2_show = cv2.resize(self.c2, (300, 300))
        self.qim1 = QImage(self.c1_show.data, self.c1_show.shape[1], self.c1_show.shape[0], self.c1_show.strides[0],
                           QImage.Format_RGB888)
        self.qim2 = QImage(self.c2_show.data, self.c2_show.shape[1], self.c2_show.shape[0], self.c2_show.strides[0],
                           QImage.Format_RGB888)
        self.qpx1 = QPixmap.fromImage(self.qim1)
        self.qpx2 = QPixmap.fromImage(self.qim2)
        self.label.setPixmap(self.qpx1)
        self.label_2.setPixmap(self.qpx2)

        h, w = self.c1.shape[:2]
        self.label_6.setText(str(h) + 'x' + str(w))
        self.cd = None
        self.cr = None
        self.lab_f = None
        self.more = None
        self.rep = 0

    def btn_clicked_3(self):
        tic = time.clock()

        sat_f = self.c1.astype('float') / 255
        lab_f = self.c2.astype('float') / 255

        h, w = self.c1.shape[:2]

        temp_beta_cd = sat_f[0:h - 1, 0:w, :] - sat_f[1:h, 0:w, :]
        temp_beta_cr = sat_f[0:h, 0:w - 1, :] - sat_f[0:h, 1:w, :]
        temp_square_cd = temp_beta_cd * temp_beta_cd
        temp_square_cr = temp_beta_cr * temp_beta_cr

        temp_sum_cd = np.sum(temp_square_cd)
        temp_sum_cr = np.sum(temp_square_cr)
        temp = temp_sum_cd + temp_sum_cr

        alpha = -1.2
        beta = h * w * 3 / temp
        num_iter = 3

        loss_square_cd = np.exp(-beta * np.sum(temp_square_cd, axis=2)) * alpha
        loss_square_cr = np.exp(-beta * np.sum(temp_square_cr, axis=2)) * alpha

        self.cd = loss_square_cd
        self.cr = loss_square_cr

        bui_f = lab_f[:, :, 1]
        roa_f = lab_f[:, :, 2]

        bui_iter = 0.5 * np.ones((h, w))
        roa_iter = 0.5 * np.ones((h, w))

        for i in range(num_iter):
            temp_bui = mean_field(loss_square_cd, loss_square_cr, bui_f, bui_iter)
            temp_roa = mean_field(loss_square_cd, loss_square_cr, roa_f, roa_iter)
            bui_iter = temp_bui.copy()
            roa_iter = temp_roa.copy()

        oth_iter = 1 - (bui_iter + roa_iter)

        res_lab = np.zeros((h, w, 3))
        res_lab[:, :, 0] = oth_iter
        res_lab[:, :, 1] = bui_iter
        res_lab[:, :, 2] = roa_iter

        temp4 = res_lab * 255
        self.c4 = temp4.astype('uint8')
        self.c4_show = cv2.resize(self.c4, (300, 300))
        self.qim4 = QImage(self.c4_show.data, self.c4_show.shape[1], self.c4_show.shape[0], self.c4_show.strides[0],
                           QImage.Format_RGB888)
        self.qpx4 = QPixmap.fromImage(self.qim4)
        self.label_3.setPixmap(self.qpx4)

        toc = time.clock()

        process_time = '%4.2f' % (toc - tic)
        # print process_time
        self.label_8.setText(process_time)

        # self.fn_res = self.fn[:len(self.fn)-8]+'_res.png'
        # cv2.imwrite(str(self.fn_res), self.c4)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = MyWindow()
    myWindow.show()
    app.exec_()
