from __future__ import print_function

import os
import sys
import time
from datetime import datetime

import numpy as np
import tensorflow as tf

PATCH = [33, 33]
NUM_CHANNELS = [4, 9]
NUM_LABEL = 5
SHAPE = (4, 240, 240, 155)
KERNEL = [3, 3]
FILTERS = [64, 128, 256]
NUM_EPOCHS = 20
BATCH_SIZE = 128
EVAL_FREQUENCY = 100
LR = 0.001
FinalLR = 0.00003
DO_RATE = 0.5
SSD_READ_PATH = "/home/wltjr1007/PycharmProjects/CNNforBRATS/output/"
HDD_READ_PATH = "/media/wltjr1007/hdd1/personal/brats/output_old/"


def get_conv_weight_bias(name, filtercnt, shape, trainable):
    weights = tf.get_variable(name=name + "w", shape=shape, initializer=tf.contrib.layers.xavier_initializer_conv2d(),
                              dtype=tf.float32, trainable=trainable)
    biases = tf.Variable(tf.constant(0.1, shape=[filtercnt], dtype=tf.float32), name=name + "b", trainable=trainable)
    return weights, biases


def get_fc_weight_bias(name, inputcnt, filtercnt, trainable):
    weights = tf.get_variable(name=name + "w", shape=([inputcnt, filtercnt]),
                              initializer=tf.contrib.layers.xavier_initializer_conv2d(), dtype=tf.float32,
                              trainable=trainable)
    biases = tf.Variable(tf.constant(0.1, shape=[filtercnt], dtype=tf.float32), name=name + "b", trainable=trainable)
    return weights, biases


# def import_weight_bias(name):
#     weights = tf.get_variable(name+"w")
#     biases = tf.get_variable(name+"b")
#     return weights, biases


def get_conv_layer(name, data, weight, bias, padding="SAME", is_inception=False):
    conv = tf.nn.conv2d(input=data, filter=weight, strides=[1, 1, 1, 1], padding=padding, name=name + "l")
    if is_inception:
        return tf.nn.bias_add(conv, bias)
    return get_leaky_relu(tf.nn.bias_add(conv, bias))


def get_leaky_relu(data):
    return tf.nn.relu(data)


def get_maxpool_layer(name, data):
    return tf.nn.max_pool(value=data, ksize=[1, 3, 3, 1], strides=[1, 2, 2, 1], padding="VALID", name=name)


def get_fc_layer(name, data, weight, bias, dropout, batch_norm=False):
    shp = data.get_shape().as_list()
    newshp = 1
    for i in range(1, len(shp)):
        newshp *= shp[i]
    print(np.prod(data.get_shape()[1:]))

    hidden = tf.nn.bias_add(tf.matmul(tf.reshape(data, [shp[0], newshp]), weight), bias)
    if batch_norm:
        hidden = tf.contrib.layers.batch_norm(hidden)
    hidden = tf.nn.relu(hidden, name=name + "r")
    if dropout < 1.:
        hidden = tf.nn.dropout(hidden, dropout, name=name + "d")
    return hidden


def get_output_layer(data, weight, bias, label):
    shp = data.get_shape().as_list()
    newshp = 1
    for i in range(1, len(shp)):
        newshp *= shp[i]
    hidden = tf.reshape(data, [shp[0], newshp])
    hidden = tf.nn.bias_add(tf.matmul(hidden, weight), bias)
    if label is None:
        return None, tf.nn.softmax(hidden)
    return tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(hidden, label)), tf.nn.softmax(hidden)


def tf_model(train_data_node, train_labels_node, trainable=True,
             mode=0, patch_size=PATCH):
    # mode: 0(phase 1-CNN), 1(extract), 2(phase 2-MLP), 3(phase-3 CNN), 4(test phase-3 CNN), 5(large Receptive field CNN added)
    # 6(LR CNN test), 7(inception module train), 8(inception module test)




    if mode == 1 or mode == 2 or mode == 0:
        c1w, c1b = get_conv_weight_bias("c1", FILTERS[0], [KERNEL[0], KERNEL[1], NUM_CHANNELS[0], FILTERS[0]],
                                        trainable)
    elif mode == 7 or mode == 8:
        kernel_size = [11, 9, 7, 4]
        i1w, i1b = get_conv_weight_bias("ic1", FILTERS[0] / 4,
                                        [kernel_size[0], kernel_size[0], NUM_CHANNELS[1], FILTERS[0] / 4],
                                        trainable)
        i2w, i2b = get_conv_weight_bias("ic2", FILTERS[0] / 4,
                                        [kernel_size[1], kernel_size[1], NUM_CHANNELS[1], FILTERS[0] / 4],
                                        trainable)
        i3w, i3b = get_conv_weight_bias("ic3", FILTERS[0] / 4,
                                        [kernel_size[2], kernel_size[2], NUM_CHANNELS[1], FILTERS[0] / 4],
                                        trainable)
        i4w, i4b = get_conv_weight_bias("ic4", FILTERS[0] / 4,
                                        [kernel_size[2], kernel_size[2], NUM_CHANNELS[1], FILTERS[0] / 4],
                                        trainable)

        inception1 = get_conv_layer("ic1", train_data_node, i1w, i1b, padding="SAME")
        inception2 = get_conv_layer("ic2", train_data_node, i2w, i2b, padding="SAME")
        inception3 = get_conv_layer("ic3", train_data_node, i3w, i3b, padding="SAME")
        inception4 = get_conv_layer("ic4", train_data_node, i4w, i4b, padding="SAME")

        concat_layer = tf.concat(3, [inception1, inception2, inception3, inception4])
        hidden1 = tf.nn.relu(concat_layer)

    else:
        c1w, c1b = get_conv_weight_bias("2c1", FILTERS[0], [KERNEL[0], KERNEL[1], NUM_CHANNELS[1], FILTERS[0]],
                                        trainable)
    c2w, c2b = get_conv_weight_bias("c2", FILTERS[0], [KERNEL[0], KERNEL[1], FILTERS[0], FILTERS[0]], trainable)
    c3w, c3b = get_conv_weight_bias("c3", FILTERS[1], [KERNEL[0], KERNEL[1], FILTERS[0], FILTERS[1]], trainable)
    c4w, c4b = get_conv_weight_bias("c4", FILTERS[1], [KERNEL[0], KERNEL[1], FILTERS[1], FILTERS[1]], trainable)
    c5w, c5b = get_conv_weight_bias("c5", FILTERS[1], [KERNEL[0], KERNEL[1], FILTERS[1], FILTERS[1]], trainable)
    c6w, c6b = get_conv_weight_bias("c6", FILTERS[1], [KERNEL[0], KERNEL[1], FILTERS[1], FILTERS[1]], trainable)

    f1w, f1b = get_fc_weight_bias("f1", 7 * 7 * 128, FILTERS[2], trainable)
    f2w, f2b = get_fc_weight_bias("f2", FILTERS[2], FILTERS[2], trainable)
    f3w, f3b = get_fc_weight_bias("f3", FILTERS[2], NUM_LABEL, trainable)

    if mode == 5 or mode == 6:
        # kernel_size = patch_size[0] - PATCH[0] + 2
        kernel_size = [11, 7]
        n1w, n1b = get_conv_weight_bias("ac1", FILTERS[0],
                                        [kernel_size[0], kernel_size[0], NUM_CHANNELS[1], FILTERS[0]],
                                        trainable)
        n2w, n2b = get_conv_weight_bias("ac2", NUM_CHANNELS[1],
                                        [kernel_size[1], kernel_size[1], FILTERS[0], NUM_CHANNELS[1]],
                                        trainable)
        add_hidden1 = get_conv_layer("ac1", train_data_node, n1w, n1b, padding="SAME")
        train_data_node = get_conv_layer("ac2", add_hidden1, n2w, n2b, padding="SAME")

    if mode != 7 and mode != 8:
        hidden1 = get_conv_layer("c1", train_data_node, c1w, c1b)
    hidden2 = get_conv_layer("c2", hidden1, c2w, c2b)
    hidden3 = get_conv_layer("c3", hidden2, c3w, c3b)
    hidden4 = get_maxpool_layer("p1", hidden3)
    hidden5 = get_conv_layer("c4", hidden4, c4w, c4b)
    hidden6 = get_conv_layer("c5", hidden5, c5w, c5b)
    hidden7 = get_conv_layer("c6", hidden6, c6w, c6b)
    hidden8 = get_maxpool_layer("p2", hidden7)
    if mode == 1:
        hidden9 = get_fc_layer("f1", hidden8, f1w, f1b, 1.)
        hidden10 = get_fc_layer("f2", hidden9, f2w, f2b, 1.)
    elif mode == 2:
        hidden9 = get_fc_layer("f1", hidden8, f1w, f1b, 1.)
        hidden10 = get_fc_layer("f2", hidden9, f2w, f2b, 1.)
        loss, train_prediction = get_output_layer(hidden10, f3w, f3b, train_labels_node)
        return hidden10, train_prediction
    elif mode == 4 or mode == 6 or mode == 8:
        hidden9 = get_fc_layer("f1", hidden8, f1w, f1b, 1.)
        hidden10 = get_fc_layer("f2", hidden9, f2w, f2b, 1.)
        _, train_prediction = get_output_layer(hidden10, f3w, f3b, train_labels_node)
        return train_prediction
    else:
        print("seoibjsoeirjg")
        hidden9 = get_fc_layer("f1", hidden8, f1w, f1b, DO_RATE)
        hidden10 = get_fc_layer("f2", hidden9, f2w, f2b, DO_RATE)
    loss, train_prediction = get_output_layer(hidden10, f3w, f3b, train_labels_node)
    return loss, train_prediction


def train_main(dataset):
    train_labels = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_train.lbl"), dtype=np.int8, mode="r")
    print(train_labels.shape)
    train_data = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_train.dat"), dtype=np.float32, mode="r").reshape(-1,
                                                                                                                    PATCH[
                                                                                                                        0],
                                                                                                                    PATCH[
                                                                                                                        1],
                                                                                                                    NUM_CHANNELS[
                                                                                                                        1])
    print(train_data.shape)
    train_size = train_labels.shape[0]
    train_data_node = tf.placeholder(tf.float32,
                                     shape=(BATCH_SIZE, PATCH[0], PATCH[1], NUM_CHANNELS[0]))
    train_labels_node = tf.placeholder(tf.int64, shape=BATCH_SIZE)

    loss, train_prediction = tf_model(train_data_node, train_labels_node)

    batch = tf.Variable(0, dtype=tf.float32)  # LR*D^EPOCH=FLR --> LR/FLR
    learning_rate = tf.train.exponential_decay(learning_rate=LR, global_step=batch * BATCH_SIZE,
                                               decay_steps=train_size, staircase=True,
                                               decay_rate=np.power(FinalLR / LR, np.float(1) / NUM_EPOCHS))
    optimizer = tf.train.MomentumOptimizer(learning_rate, 0.9).minimize(loss, global_step=batch)
    predict = tf.to_double(100) * (
        tf.to_double(1) - tf.reduce_mean(tf.to_double(tf.nn.in_top_k(train_prediction, train_labels_node, 1))))

    start_time = time.time()

    allmean, allstd = np.load(os.path.join("/media/wltjr1007/hdd1/personal/brats/output_old/", dataset + "_zmuv.npy"))
    with tf.Session() as sess:
        tf.initialize_all_variables().run()
        print("Variable Initialized")
        tf.scalar_summary("error", predict)
        summary_op = tf.merge_all_summaries()
        summary_writer = tf.train.SummaryWriter(
            "/media/wltjr1007/hdd1/personal/brats/output/summary/" + str(int(time.time())), sess.graph)
        cnttt = 0
        saver = tf.train.Saver(keep_checkpoint_every_n_hours=2, max_to_keep=30)
        randidx = np.random.permutation(np.arange(train_size, dtype=np.uint32))

        # saver.restore(sess, "/media/wltjr1007/hdd1/personal/brats/output/savedmodel_final.ckpt")
        for step in range(int(NUM_EPOCHS * train_size) // BATCH_SIZE):
            offset = (step * BATCH_SIZE) % (train_size - BATCH_SIZE)
            batch_data = train_data[randidx[offset:offset + BATCH_SIZE]].copy()
            batch_labels = train_labels[randidx[offset:offset + BATCH_SIZE]].copy()
            for i in range(4):
                batch_data[..., i] -= allmean[i]
                batch_data[..., i] /= allstd[i]
            feed_dict = {train_data_node: batch_data, train_labels_node: batch_labels}
            _, l, lr, predictions, summary_out = sess.run(
                [optimizer, loss, learning_rate, predict, summary_op],
                feed_dict=feed_dict)
            if step % EVAL_FREQUENCY == 0:
                elapsed_time = time.time() - start_time
                start_time = time.time()
                summary_writer.add_summary(summary_out, global_step=step)
                print(str(datetime.now()))
                print('Step %d (epoch %.2f), %d s' %
                      (step, float(step) * BATCH_SIZE / train_size, elapsed_time))
                print('Minibatch loss: %.3f, learning rate: %.6f' % (l, lr))
                print('Minibatch error: %.1f%%' % predictions)
                sys.stdout.flush()
            if cnttt != (step * BATCH_SIZE) / train_size:  # 1 epoch ((450000*4)/(128*100))*2min=281min=4.5hours.
                print("Saved in path",
                      saver.save(sess, "/media/wltjr1007/hdd1/personal/brats/output_old/savedmod/" + str(
                          cnttt) + ".ckpt"))
                np.random.shuffle(randidx)
            cnttt = (step * BATCH_SIZE) / train_size
        print("Saved in path",
              saver.save(sess, "/media/wltjr1007/hdd1/personal/brats/output_old/savedmod/savedmodel_final.ckpt"))
    tf.reset_default_graph()


def test_PM_CNN(dataset, isMean=None, test_set=None, patch_size=PATCH, is_inception=False):
    data_name = get_img_name_list("/media/wltjr1007/hdd1/personal/brats/data/")
    # NEW_SHAPE = (SHAPE[0], SHAPE[1] - PATCH[0] + 1, SHAPE[2] - PATCH[1] + 1, SHAPE[3])
    train_data = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_train_2_out.dat"), dtype=np.float32,
                           mode="r").reshape((-1, NUM_CHANNELS[1], SHAPE[1], SHAPE[2], SHAPE[3]))

    train_size = train_data.shape[0]

    # loss, train_prediction = tf_model(train_data_node, train_labels_node, True, mode=5, patch_size=patch_size)
    train_data_node = tf.placeholder(tf.float32,
                                     shape=(SHAPE[3], patch_size[0], patch_size[1],
                                            NUM_CHANNELS[1]))
    mode = 6
    if is_inception:
        mode = 8
    train_prediction = tf_model(train_data_node, None, False, mode=mode, patch_size=patch_size)
    allmean = np.zeros(NUM_CHANNELS[1], dtype=np.float32)
    allstd = np.ones(NUM_CHANNELS[1], dtype=np.float32)
    allmean[:NUM_CHANNELS[0]], allstd[:NUM_CHANNELS[0]] = np.load(
        os.path.join("/media/wltjr1007/hdd1/personal/brats/output/", "h_zmuv.npy"))
    import medpy.io as medpyio
    imghdr = medpyio.load("/media/wltjr1007/hdd1/personal/brats/data/h.1.VSD.Brain.XX.O.MR_Flair.54512.nii")[1]
    model_path = HDD_READ_PATH + "savedmodel3_%d_%d_%d/" % (isMean[0], patch_size[0], int(is_inception))
    result_path = HDD_READ_PATH + dataset + "_train_final_%d_%d_%d.dat" % (isMean[0], patch_size[0], int(is_inception))

    img_path = HDD_READ_PATH + "testoutput2_%d_%d_%d/" % (isMean[0], patch_size[0], int(is_inception))
    if not os.path.exists(img_path):
        os.makedirs(img_path)
    with tf.Session() as sess:
        tf.initialize_all_variables().run()
        saver = tf.train.Saver()
        saver.restore(sess, model_path + "10.ckpt")
        # saver.restore(sess, HDD_READ_PATH + "savedmodel3/savedmodel_final.ckpt")
        train_out_data = np.memmap(result_path, dtype=np.float32,
                                   shape=(train_size, NUM_CHANNELS[1], SHAPE[1], SHAPE[2], SHAPE[3]), mode="w+")
        # cnt = 0
        start_time = time.time()
        print("Variable Initialized(extract 2)", datetime.now())
        if test_set is None:
            test_set = range(train_size)
        for i in test_set:
            curdata = train_data[i, :NUM_CHANNELS[0]].copy()
            curpm = train_data[i, NUM_CHANNELS[0]:].copy()
            train_out_data[i, :NUM_CHANNELS[0]] = curdata
            rolled_data = np.rollaxis(curdata, 0, 4)
            rolled_pm = np.rollaxis(curpm, 0, 4)
            if isMean[0] != 0:
                rolled_pm = rolling_window(rolled_pm, isMean)
                rolled_pm = np.mean(rolled_pm, axis=(-1, -2))
                pad_size = [SHAPE[1] - rolled_pm.shape[0], SHAPE[2] - rolled_pm.shape[1]]
                rolled_pm = np.pad(rolled_pm, (
                (pad_size[0] / 2, pad_size[0] / 2), (pad_size[1] / 2, pad_size[1] / 2), (0, 0), (0, 0)), "edge")

            rolled_data = np.append(rolled_data, rolled_pm, axis=-1)
            rolled_data = rolling_window(rolled_data, (patch_size[0], patch_size[1]))
            rolled_data = np.rollaxis(rolled_data, 3, 6)

            result = np.zeros(shape=(rolled_data.shape[0], rolled_data.shape[1], rolled_data.shape[2], NUM_LABEL),
                              dtype=np.float32)

            local_time = time.time()
            for height in range(rolled_data.shape[0]):
                for width in range(rolled_data.shape[1]):
                    curtemp = rolled_data[height, width]
                    if np.all(curtemp[..., :NUM_CHANNELS[0]] == 0):
                        result[height, width, ..., 0] = 1
                        continue
                    feed_dict = {train_data_node: (curtemp - allmean) / allstd}
                    result[height, width] = sess.run(train_prediction, feed_dict=feed_dict)
                print("\rExtract data. Patient:", i + 1, "/", np.shape(test_set), height + 1, "/", rolled_data.shape[0],
                      time.time() - start_time, time.time() - local_time, end="")
                # if height == 40 or height==30:
                #     for asdf in range(5):
                #         ax = plt.subplot(1,5,asdf+1)
                #         ax.imshow(result[height,...,asdf])
                #     plt.show()
                local_time = time.time()
            pad_size = [SHAPE[1] - rolled_data.shape[0], SHAPE[2] - rolled_data.shape[1]]
            result = np.pad(result,
                            ((pad_size[0] / 2, pad_size[0] / 2), (pad_size[1] / 2, pad_size[1] / 2), (0, 0), (0, 0)),
                            "edge")

            zidx = np.argwhere(train_out_data[i, 0] == 0)
            result[zidx[:, 0], zidx[:, 1], zidx[:, 2], 0] = 1
            result[zidx[:, 0], zidx[:, 1], zidx[:, 2], 1:] = 0

            train_out_data[i, NUM_CHANNELS[0]:] = np.rollaxis(result, -1, 0)
            file_name = img_path + "VSD.%s_%d_%d_%d_%d.%d.nii" % (
            dataset, i, isMean[0], patch_size[0], int(time.time()), int(data_name[2][i, 3]))
            # if isMean is None:
            #     img_path=HDD_READ_PATH + "testoutput2/VSD.t_" + str(i) + "_"+str(int(time.time()))+"." + data_name[2][i, 3]+".nii"
            # else:
            #     img_path=HDD_READ_PATH + "testoutput2/VSD.t_" + str(i) + "_mean_"+str(int(time.time()))+"." + data_name[2][i, 3]+".nii"
            medpyio.save(np.argmax(result, axis=-1).astype(np.uint8), file_name, imghdr)

    tf.reset_default_graph()
    print("\nExtract data 2 end", datetime.now())


def train_MLP(dataset):
    new_patch = np.memmap(HDD_READ_PATH + "h_train_3_in.dat", dtype=np.float32, mode="r").reshape(
        (-1, PATCH[0], PATCH[1], NUM_CHANNELS[0]))
    train_size = new_patch.shape[0]
    new_patch_lbl = np.memmap(HDD_READ_PATH + "h_train_3_in.lbl", dtype=np.int8, mode="r", shape=train_size)
    train_data_node = tf.placeholder(tf.float32, shape=(220, PATCH[0], PATCH[1], NUM_CHANNELS[0]))
    train_labels_node = tf.placeholder(tf.int64, shape=220)
    non_linear_holder, temp_softmax = tf_model(train_data_node, None, False, mode=2)
    predict = tf.to_double(100) * (
        tf.to_double(1) - tf.reduce_mean(tf.to_double(tf.nn.in_top_k(temp_softmax, train_labels_node, 1))))
    allmean, allstd = np.load(os.path.join("/media/wltjr1007/hdd1/personal/brats/output/", dataset + "_zmuv.npy"))
    tempobject = np.empty((new_patch.shape[0], 256), dtype=np.float32)
    with tf.Session() as sess:
        tf.initialize_all_variables().run()
        tf.scalar_summary("error", predict)
        # summary_op = tf.merge_all_summaries()
        # summary_writer = tf.train.SummaryWriter(
        #     "/media/wltjr1007/hdd1/personal/brats/output/summary2/" + str(int(time.time())), sess.graph)
        saver = tf.train.Saver()
        saver.restore(sess, HDD_READ_PATH + "savedmodel/savedmodel_final.ckpt")
        print("Variable Initialized(phase 2)", datetime.now())
        for i in range(0, train_size, 220):
            curdata = new_patch[i:i + 220].copy()
            curdata -= allmean
            curdata /= allstd
            feed_dict = {train_data_node: curdata, train_labels_node: new_patch_lbl[i:i + 220]}
            tempobject[i:i + 220], temp_predict = sess.run([non_linear_holder, predict], feed_dict=feed_dict)
            # summary_writer.add_summary(summary_out, global_step=i*220)
    tf.reset_default_graph()
    print("\nPhase 2 end", datetime.now())
    NUM_EPOCHS = 1000
    train_data_node = tf.placeholder(tf.float32, shape=(BATCH_SIZE, 256))
    train_labels_node = tf.placeholder(tf.int64, shape=BATCH_SIZE)
    f1w, f1b = get_fc_weight_bias("2f1", 256, 216, True)
    f2w, f2b = get_fc_weight_bias("2f2", 216, 176, True)
    f3w, f3b = get_fc_weight_bias("2f3", 176, 136, True)
    # f4w, f4b = get_fc_weight_bias("2f4",136,96,True)
    # f5w, f5b = get_fc_weight_bias("2f5",96,56,True)
    f6w, f6b = get_fc_weight_bias("2f6", 136, 5, True)
    hidden1 = get_fc_layer("2f1", train_data_node, f1w, f1b, DO_RATE, True)
    hidden2 = get_fc_layer("2f2", hidden1, f2w, f2b, DO_RATE, True)
    hidden3 = get_fc_layer("2f3", hidden2, f3w, f3b, DO_RATE, True)
    # hidden4 = get_fc_layer("2f4",hidden3, f4w, f4b, DO_RATE,True)
    loss, train_prediction = get_output_layer(hidden3, f6w, f6b, train_labels_node)
    # hidden5 = get_fc_layer("2f5",hidden4, f5w, f5b, DO_RATE,True)
    # loss, train_prediction = get_output_layer(hidden5, f6w, f6b, train_labels_node)
    LR = 0.01
    batch = tf.Variable(0, dtype=tf.float32)  # LR*D^EPOCH=FLR --> LR/FLR
    learning_rate = tf.train.exponential_decay(learning_rate=LR, global_step=batch * BATCH_SIZE,
                                               decay_steps=train_size, staircase=True,
                                               decay_rate=np.power(FinalLR / LR, np.float(1) / NUM_EPOCHS))
    optimizer = tf.train.MomentumOptimizer(learning_rate, 0.9).minimize(loss, global_step=batch)
    predict = tf.to_double(100) * (
        tf.to_double(1) - tf.reduce_mean(tf.to_double(tf.nn.in_top_k(train_prediction, train_labels_node, 1))))

    start_time = time.time()
    with tf.Session() as sess:
        tf.initialize_all_variables().run()
        print("Variable Initialized")
        tf.scalar_summary("error", predict)
        summary_op = tf.merge_all_summaries()
        summary_writer = tf.train.SummaryWriter(
            "/media/wltjr1007/hdd1/personal/brats/output/summary2/" + str(int(time.time())), sess.graph)
        cnttt = 0
        saver = tf.train.Saver(keep_checkpoint_every_n_hours=2, max_to_keep=30)
        for step in range(int(NUM_EPOCHS * train_size) // BATCH_SIZE):
            offset = (step * BATCH_SIZE) % (train_size - BATCH_SIZE)
            batch_data = tempobject[offset:offset + BATCH_SIZE]
            batch_labels = new_patch_lbl[offset:offset + BATCH_SIZE]
            feed_dict = {train_data_node: batch_data, train_labels_node: batch_labels}
            _, l, lr, predictions, summary_out = sess.run(
                [optimizer, loss, learning_rate, predict, summary_op],
                feed_dict=feed_dict)
            summary_writer.add_summary(summary_out, global_step=(step * BATCH_SIZE))
            if cnttt != (step * BATCH_SIZE) / train_size:
                elapsed_time = time.time() - start_time
                start_time = time.time()
                print(str(datetime.now()))
                print('Step %d (epoch %.2f), %d s' %
                      (step, float(step) * BATCH_SIZE / train_size, elapsed_time))
                print('Minibatch loss: %.3f, learning rate: %.6f' % (l, lr))
                print('Minibatch error: %.1f%%' % predictions)
                sys.stdout.flush()
            if cnttt != (step * BATCH_SIZE) / train_size:  # 1 epoch ((450000*4)/(128*100))*2min=281min=4.5hours.
                print("Saved in path",
                      saver.save(sess, "/media/wltjr1007/hdd1/personal/brats/output/savedmodel2/" + str(
                          cnttt) + ".ckpt"))
            cnttt = (step * BATCH_SIZE) / train_size
        print("Saved in path",
              saver.save(sess, "/media/wltjr1007/hdd1/personal/brats/output/savedmodel2/savedmodel_final.ckpt"))
    tf.reset_default_graph()


def train_PM_CNN(dataset, mean_size=(0, 0), patch_size=PATCH, is_inception=False):
    train_labels = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_train_3_out.lbl"), dtype=np.int8, mode="r")
    data_path = HDD_READ_PATH + dataset + "_train_3_%d_%d_out.dat" % (mean_size[0], patch_size[0])
    model_path = HDD_READ_PATH + "savedmodel3_%d_%d_%d/" % (mean_size[0], patch_size[0], int(is_inception))
    summary_path = HDD_READ_PATH + "summary3_%d_%d_%d/" % (mean_size[0], patch_size[0], int(is_inception))
    if not os.path.exists(model_path):
        os.makedirs(model_path)
    if not os.path.exists(summary_path):
        os.makedirs(summary_path)
    train_data = np.memmap(data_path, dtype=np.float32, mode="r",
                           shape=(train_labels.shape[0], patch_size[0], patch_size[1], NUM_CHANNELS[1]))
    train_data = train_data[:(train_data.shape[0] // BATCH_SIZE) * BATCH_SIZE]
    train_size = train_data.shape[0]
    train_labels = train_labels[:train_size]

    train_data_node = tf.placeholder(tf.float32, shape=(BATCH_SIZE, patch_size[0], patch_size[1], NUM_CHANNELS[1]))
    train_labels_node = tf.placeholder(tf.int64, shape=BATCH_SIZE)
    mode = 5
    if is_inception:
        mode = 7
    loss, train_prediction = tf_model(train_data_node, train_labels_node, True, mode=mode, patch_size=patch_size)
    batch = tf.Variable(0, dtype=tf.float32)
    learning_rate = tf.train.exponential_decay(learning_rate=LR, global_step=batch * BATCH_SIZE,
                                               decay_steps=train_size, staircase=True,
                                               decay_rate=np.power(FinalLR / LR, np.float(1) / NUM_EPOCHS))
    optimizer = tf.train.MomentumOptimizer(learning_rate, 0.9).minimize(loss, global_step=batch)
    predict = tf.to_double(100) * (
        tf.to_double(1) - tf.reduce_mean(tf.to_double(tf.nn.in_top_k(train_prediction, train_labels_node, 1))))
    with tf.Session() as sess:
        tf.initialize_all_variables().run()
        tf.scalar_summary("error", predict)

        summary_op = tf.merge_all_summaries()
        summary_writer = tf.train.SummaryWriter(
            summary_path + str(int(time.time())), sess.graph)
        cnttt = 0
        saver = tf.train.Saver(keep_checkpoint_every_n_hours=2, max_to_keep=30)
        start_time = time.time()
        # saver.restore(sess, HDD_READ_PATH + "savedmodel/savedmodel_final.ckpt")
        print("Variable Initialized", datetime.now())
        for step in range(int(NUM_EPOCHS * train_size) // BATCH_SIZE):
            # offset = (step * BATCH_SIZE) % (train_size - BATCH_SIZE)
            # curidx = np.sort(randidx[offset:offset + BATCH_SIZE])
            offset = step % BATCH_SIZE
            batch_data = train_data[offset::train_size / BATCH_SIZE]
            batch_labels = train_labels[offset::train_size / BATCH_SIZE]
            feed_dict = {train_data_node: batch_data, train_labels_node: batch_labels}
            _, l, lr, predictions, summary_out = sess.run(
                [optimizer, loss, learning_rate, predict, summary_op],
                feed_dict=feed_dict)
            summary_writer.add_summary(summary_out, global_step=step * BATCH_SIZE)
            if step % EVAL_FREQUENCY == 0:
                elapsed_time = time.time() - start_time
                start_time = time.time()
                print(str(datetime.now()))
                print('Step %d (epoch %.2f), %d s' %
                      (step, float(step) * BATCH_SIZE / train_size, elapsed_time))
                print('Minibatch loss: %.3f, learning rate: %.6f' % (l, lr))
                print('Minibatch error: %.1f%%' % predictions)
                sys.stdout.flush()
            if cnttt != (step * BATCH_SIZE) / train_size:  # 1 epoch ((450000*4)/(128*100))*2min=281min=4.5hours.
                print("Saved in path",
                      saver.save(sess, model_path + str(
                          cnttt) + ".ckpt"))

            cnttt = (step * BATCH_SIZE) / train_size
        print("Saved in path",
              saver.save(sess, model_path + "savedmodel_final.ckpt"))
    tf.reset_default_graph()
    print("\nTrain 2 end", datetime.now())


# def extract(dataset):
#     batch_size = 128
#     train2_data = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_train_2.dat"), dtype=np.float32, mode="r").reshape(
#         (-1, PATCH[0] + 2 * (PATCH[0] // 2), PATCH[1] + 2 * (PATCH[1] // 2), NUM_CHANNELS[0]))
#     train_size = train2_data.shape[0]
#
#     # train_data_node = tf.placeholder(tf.float32, shape=(batch_size, PATCH[0], PATCH[1], NUM_CHANNELS[0]))
#     train_data_node = tf.placeholder(tf.float32, shape=(batch_size, PATCH[0], PATCH[1], NUM_CHANNELS[0]))
#     _, train_prediction = tf_model(train_data_node, None, False)
#
#     allmean, allstd = np.load(os.path.join("/media/wltjr1007/hdd1/personal/brats/output/", dataset + "_zmuv.npy"))
#     with tf.Session() as sess:
#         tf.initialize_all_variables().run()
#         saver = tf.train.Saver()
#         saver.restore(sess, HDD_READ_PATH + "savedmodel/savedmodel_final.ckpt")
#         print("Variable Initialized(extract 1)", datetime.now())
#
#         start_time = time.time()
#         smresult = np.zeros((train_size, 5), dtype=np.float32)
#         tempdata = np.empty((batch_size, PATCH[0], PATCH[1], NUM_CHANNELS[0]), dtype=np.float32)
#         for i in range(train_size):
#             curdata = train2_data[i, PATCH[0] // 2:-(PATCH[0] // 2), PATCH[1] // 2:-(PATCH[1] // 2)].copy()
#             curdata -= allmean
#             curdata /= allstd
#             tempdata[i % batch_size] = curdata
#             if i % batch_size == 0 and i > 0:
#                 feed_dict = {train_data_node: tempdata}
#                 result = sess.run(train_prediction, feed_dict=feed_dict)
#                 smresult[i - batch_size:i] = result
#                 tempdata = np.empty((batch_size, PATCH[0], PATCH[1], NUM_CHANNELS[0]), dtype=np.float32)
#                 if i % (batch_size * 10) == 0:
#                     elapsed_time = time.time() - start_time
#                     start_time = time.time()
#                     print("\rExtract data", i, "/", train_size, elapsed_time, end="")
#             elif i == train_size - 1:
#                 feed_dict = {train_data_node: tempdata}
#                 result = sess.run(train_prediction, feed_dict=feed_dict)
#                 smresult[batch_size * (train_size // batch_size):] = result[:train_size - batch_size * (
#                     train_size // batch_size)]
#         min_sm = np.argsort(np.max(smresult, axis=1))[:200000]
#         with open(os.path.join(HDD_READ_PATH, "sm_min.txt"), 'wb') as f:
#             pickle.dump(min_sm, f)
#     tf.reset_default_graph()


def extract_PM(dataset, mode, resume=0):
    NEW_SHAPE = (SHAPE[0], SHAPE[1] - PATCH[0] + 1, SHAPE[2] - PATCH[1] + 1, SHAPE[3])
    train_data = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_orig.dat"), dtype=np.float32, mode="r").reshape(
        (-1, SHAPE[0], SHAPE[1], SHAPE[2], SHAPE[3]))
    train_size = train_data.shape[0]
    print(train_size, dataset)
    train_data_node = tf.placeholder(tf.float32, shape=(SHAPE[3], PATCH[0], PATCH[1], NUM_CHANNELS[0]))
    _, train_prediction = tf_model(train_data_node, None, False, mode)
    allmean, allstd = np.load(os.path.join("/media/wltjr1007/hdd1/personal/brats/output/", "h_zmuv.npy"))
    with tf.Session() as sess:
        tf.initialize_all_variables().run()
        saver = tf.train.Saver()
        saver.restore(sess, HDD_READ_PATH + "savedmodel/savedmodel_final.ckpt")
        train_out_data = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_train_2_out.dat"), dtype=np.float32,
                                   shape=(train_size, NUM_CHANNELS[1], SHAPE[1], SHAPE[2], SHAPE[3]), mode="r+")
        start_time = time.time()

        rolled_data = np.rollaxis(np.rollaxis(train_data, 0, -1), 0, -1)
        rolled_data = rolling_window(rolled_data, (PATCH[0], PATCH[1]))
        rolled_data = np.rollaxis(np.rollaxis(rolled_data, 2, 0), 3, 7)

        print("Variable Initialized(extract 2)", datetime.now())
        for i in range(resume, train_size):
            result = np.zeros((NEW_SHAPE[1], NEW_SHAPE[2], SHAPE[3], NUM_LABEL), dtype=np.float32)
            local_time = time.time()
            for width in range(NEW_SHAPE[1]):
                for height in range(NEW_SHAPE[2]):
                    curdata = rolled_data[i, width, height]
                    if np.all(curdata == 0):
                        result[width, height, ..., 0] = 1
                        continue
                    feed_dict = {train_data_node: (curdata - allmean) / allstd}
                    result[width, height] = sess.run(train_prediction, feed_dict=feed_dict)
                print("\rExtract data. Patient:", i + 1, "/", train_size, width, "/", NEW_SHAPE[2],
                      time.time() - start_time, time.time() - local_time, end="")
                local_time = time.time()
            result = np.pad(result, ((16, 16), (16, 16), (0, 0), (0, 0)), "edge")
            zidx = np.argwhere(train_out_data[i, 0] == 0)
            result[zidx[:, 0], zidx[:, 1], zidx[:, 2], 0] = 1
            result[zidx[:, 0], zidx[:, 1], zidx[:, 2], 1:] = 0

            train_out_data[i, NUM_CHANNELS[0]:] = np.rollaxis(result, -1, 0)

        train_out_data[:, :NUM_CHANNELS[0]] = train_data
    tf.reset_default_graph()
    print("\nExtract data 2 end", datetime.now())


def extract_attention(extract_size):  # min(max(softmax))
    data = np.memmap(os.path.join(SSD_READ_PATH, "h_train_2_out.dat"), dtype=np.float32, mode="r").reshape(-1,
                                                                                                           NUM_CHANNELS[
                                                                                                               1],
                                                                                                           SHAPE[1],
                                                                                                           SHAPE[2],
                                                                                                           SHAPE[3])

    train_labels = np.memmap(filename=os.path.join(HDD_READ_PATH, "h_gt.dat"),
                             shape=(data.shape[0], SHAPE[1], SHAPE[2], SHAPE[3]), dtype=np.int8, mode="r")
    new_patch = np.memmap(HDD_READ_PATH + "h_train_3_in.dat", dtype=np.float32, mode="r+",
                          shape=(data.shape[0] * extract_size, PATCH[0], PATCH[1], NUM_CHANNELS[0]))
    new_patch_lbl = np.memmap(HDD_READ_PATH + "h_train_3_in.lbl", dtype=np.int8, mode="r+",
                              shape=(new_patch.shape[0]))

    extractidx = np.empty((data.shape[0], extract_size, 3), dtype=np.uint8)
    for cnt in range(220):
        curslidemean = np.mean(rolling_window(np.var(data[cnt, 4:], axis=0), (33, 33)), axis=(-1, -2))
        cursort = np.transpose(np.unravel_index(np.argsort(curslidemean, None), (curslidemean.shape)))
        dupidx = np.empty((0, 3), dtype=np.uint8)
        goodidx = np.empty((extract_size, 3), dtype=np.uint8)
        cutidx = 3
        cntt = 0
        start_time = time.time()
        for aaa in cursort:
            if any(np.equal(dupidx, aaa).all(True)):
                continue
            else:
                bbb = [[aaa[0] - j, aaa[1] - k, aaa[2]] for j in range(-cutidx, cutidx + 1) for k in
                       range(-cutidx, cutidx + 1)]
                dupidx = np.append(dupidx, bbb, axis=0)
                goodidx[cntt] = aaa
                cntt += 1
                # print(cntt)
            if cntt >= extract_size:
                break
        new_patch[cnt * extract_size:(cnt + 1) * extract_size] = \
            np.rollaxis(rolling_window(np.rollaxis(data[cnt, :4], 0, 4), (33, 33)), 3, 6)[
                goodidx[:, 0], goodidx[:, 1], goodidx[:, 2]]
        new_patch_lbl[cnt * extract_size:(cnt + 1) * extract_size] = train_labels[
            cnt, goodidx[:, 0] + 16, goodidx[:, 1] + 16, goodidx[:, 2]]
        extractidx[cnt] = goodidx + [16, 16, 0]
        print("\rExtract 3 input data. Patient:", cnt + 1, "/", data.shape[0], time.time() - start_time, end="")
    np.save(HDD_READ_PATH + "ex3_idx.npy", extractidx)


def extract_PM_window(dataset, is_mean=None, patch_size=PATCH):
    train_data = np.memmap(os.path.join(SSD_READ_PATH, dataset + "_train_2_out.dat"), dtype=np.float32,
                           mode="r").reshape(-1,
                                             NUM_CHANNELS[
                                                 1],
                                             SHAPE[
                                                 1],
                                             SHAPE[
                                                 2],
                                             SHAPE[
                                                 3])
    train_labels = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_gt.dat"), dtype=np.int8, mode="r",
                             shape=(train_data.shape[0], SHAPE[1], SHAPE[2], SHAPE[3]))

    lblidx = np.load(HDD_READ_PATH + "labelidx2.npy")
    lblidx = lblidx[np.argwhere(lblidx[:, 1] > patch_size[0] / 2).squeeze()]
    lblidx = lblidx[np.argwhere(lblidx[:, 2] > patch_size[1] / 2).squeeze()]
    lblidx = lblidx[np.argwhere(lblidx[:, 1] < train_data.shape[2] - patch_size[0] / 2).squeeze()]
    lblidx = lblidx[np.argwhere(lblidx[:, 2] < train_data.shape[3] - patch_size[1] / 2).squeeze()]

    if dataset != "t":
        train_lbl_out = np.memmap(os.path.join(HDD_READ_PATH, dataset + "_train_3_out.lbl"), dtype=np.int8, mode="w+",
                                  shape=lblidx.shape[0])
        train_lbl_out[:] = train_labels[lblidx[:, 0], lblidx[:, 1], lblidx[:, 2], lblidx[:, 3]]
    extract_size = lblidx.shape[0]

    rolled_padded_idx = lblidx - [0, patch_size[0] / 2, patch_size[1] / 2, 0]

    rolled_data = np.rollaxis(np.rollaxis(train_data, 0, -1), 0, -1)
    rolled_data = rolling_window(rolled_data, (patch_size[0], patch_size[1]))
    rolled_data = np.rollaxis(np.rollaxis(rolled_data, 2, 0), 3, 7)

    allmean, allstd = np.load(os.path.join("/media/wltjr1007/hdd1/personal/brats/output/", "h_zmuv.npy"))

    start_time = time.time()
    local_start_time = time.time()

    data_path = HDD_READ_PATH + dataset + "_train_3"
    if is_mean is not None:
        data_path += "_" + str(is_mean[0])
    else:
        data_path += "_0"
    if patch_size != PATCH:
        data_path += "_" + str(patch_size[0])
    else:
        data_path += "_0"
    data_path += "_out.dat"

    if is_mean is not None:

        mean_padded_idx = lblidx - [0, patch_size[0] / 2 + is_mean[0] / 2, patch_size[0] / 2 + is_mean[0] / 2, 0]
        pre_mean_roll = np.rollaxis(np.rollaxis(train_data[:, NUM_CHANNELS[0]:], 0, -1), 0, -1)
        pre_mean_roll = rolling_window(rolling_window(pre_mean_roll, is_mean), (patch_size[0], patch_size[1]))
        pre_mean_roll = np.rollaxis(pre_mean_roll, 8, 3)
        pre_mean_roll = np.rollaxis(pre_mean_roll, 8, 3)
        pre_mean_roll = np.rollaxis(pre_mean_roll, 6, 3)
        pre_mean_roll = np.rollaxis(pre_mean_roll, 2, 0)

        train_out = np.memmap(data_path, dtype=np.float32,
                              mode="r+",
                              shape=(extract_size, patch_size[0], patch_size[1], NUM_CHANNELS[1]))
        start_time = time.time()
        local_start_time = time.time()
        print(rolled_data.shape, pre_mean_roll.shape)
        for meanidx, rollidx, curcnt in zip(mean_padded_idx, rolled_padded_idx, range(extract_size)):
            curpm = pre_mean_roll[meanidx[0], meanidx[1], meanidx[2], meanidx[3]]
            # curpm = pre_mean_roll[rollidx[0], rollidx[1],rollidx[2],rollidx[3]]
            curmean = np.mean(curpm, axis=(-1, -2))
            curdata = rolled_data[rollidx[0], rollidx[1], rollidx[2], rollidx[3], ..., :NUM_CHANNELS[0]]
            train_out[curcnt, ..., :NUM_CHANNELS[0]] = (curdata - allmean) / allstd
            train_out[curcnt, ..., NUM_CHANNELS[0]:] = curmean
            if curcnt % 1000 == 0:
                print("\rPM with mean extract", curcnt, "/", extract_size, time.time() - start_time,
                      time.time() - local_start_time, end="")
                local_start_time = time.time()


    elif is_mean is None:
        train_out = np.memmap(data_path, dtype=np.float32, mode="w+",
                              shape=(extract_size, patch_size[0], patch_size[1], NUM_CHANNELS[1]))
        for rollidx, curcnt in zip(rolled_padded_idx, range(extract_size)):
            curdata = rolled_data[rollidx[0], rollidx[1], rollidx[2], rollidx[3], ..., :NUM_CHANNELS[0]]
            curpm = rolled_data[rollidx[0], rollidx[1], rollidx[2], rollidx[3], ..., NUM_CHANNELS[0]:]
            train_out[curcnt, ..., :NUM_CHANNELS[0]] = (curdata - allmean) / allstd
            train_out[curcnt, ..., NUM_CHANNELS[0]:] = curpm
            if curcnt % 1000 == 0:
                print("\rPM extract", curcnt, "/", extract_size, time.time() - start_time,
                      time.time() - local_start_time, end="")
                local_start_time = time.time()


def rolling_window_lastaxis(a, window):
    if window < 1:
        raise ValueError("`window` must be at least 1.")
    if window > a.shape[-1]:
        raise ValueError("`window` is too long.")
    shape = a.shape[:-1] + (a.shape[-1] - window + 1, window)
    strides = a.strides + (a.strides[-1],)
    return np.lib.stride_tricks.as_strided(a, shape=shape, strides=strides)


def rolling_window(a, window):
    if not hasattr(window, '__iter__'):
        return rolling_window_lastaxis(a, window)
    for i, win in enumerate(window):
        if win > 1:
            a = a.swapaxes(i, -1)
            a = rolling_window_lastaxis(a, win)
            a = a.swapaxes(-2, i)
    return a


def get_img_name_list(path):  # h.7.VSD.Brain_3more.XX.O.OT.54553.nii
    MODS = {"T1": 0, "T2": 1, "T1c": 2, "Flair": 3, "OT": 4}
    name_list = os.listdir(path)
    result_list_l = {}
    result_list_h = {}
    result_list_t = {}
    for name in name_list:
        temp = name.replace(".nii", "").split(".")
        dataset = temp[0]
        cnt = int(temp[1]) - 1
        mod = MODS[temp[-2].split("_")[-1]]
        dbcnt = temp[-1]
        if dataset == "l":
            result_list_l[cnt, mod] = dbcnt
        elif dataset == "h":
            result_list_h[cnt, mod] = dbcnt
        elif dataset == "t":
            result_list_t[cnt, mod] = dbcnt
    return np.array([result_list_h, result_list_l, result_list_t])

# def main(argv=None):
#     train("h")
#
#
# if __name__ == '__main__':
#     tf.app.run()
