from __future__ import print_function

import numpy as np

PATCH = [33, 33]
NUM_CHANNELS = [4, 9]
NUM_LABEL = 5
SHAPE = (4, 240, 240, 155)
KERNEL = [3, 3]
FILTERS = [64, 128, 256]
NUM_EPOCHS = 20
BATCH_SIZE = 128
EVAL_FREQUENCY = 100
LR = 0.001
FinalLR = 0.00003
DO_RATE = 0.5
SSD_READ_PATH = "/home/wltjr1007/PycharmProjects/CNNforBRATS/output/"
HDD_READ_PATH = "/media/wltjr1007/hdd1/personal/brats/output/"


def rolling_window_lastaxis(a, window):
    if window < 1:
        raise ValueError("`window` must be at least 1.")
    if window > a.shape[-1]:
        raise ValueError("`window` is too long.")
    shape = a.shape[:-1] + (a.shape[-1] - window + 1, window)
    strides = a.strides + (a.strides[-1],)
    return np.lib.stride_tricks.as_strided(a, shape=shape, strides=strides)


def rolling_window(a, window):
    if not hasattr(window, '__iter__'):
        return rolling_window_lastaxis(a, window)
    for i, win in enumerate(window):
        if win > 1:
            a = a.swapaxes(i, -1)
            a = rolling_window_lastaxis(a, win)
            a = a.swapaxes(-2, i)
    return a


train_data = np.memmap("/home/wltjr1007/PycharmProjects/CNNforBRATS/output/test_this.npy", dtype=np.uint8, mode="r",
                       shape=(220, 4, 240, 240, 155))
print(train_data._mmap)
a = train_data[0].copy()
print(a._attributes)

# lblidx = np.load(HDD_READ_PATH + "labelidx2.npy")
# aamin = np.min(lblidx[:,1])
# bbmin = np.min(lblidx[:,2])
# print(aamin, bbmin)
# rolled_data = np.rollaxis(np.rollaxis(train_data[:,:,aamin:,bbmin:], 0, -1), 0, -1)
# rolled_data = rolling_window(rolled_data, (PATCH[0], PATCH[1]))
# rolled_data = np.rollaxis(np.rollaxis(rolled_data, 2, 0), 3, 7)
# print(rolled_data.shape)#(220, 167, 170, 155, 33, 33, 4)
# for a,b, in zip(rolled_data[0,192-aamin-16,112-bbmin-21, 0,:,:,1], range(100)):
#     print(b, a)
# print(rolled_data[0,])


# print(rolled_data.shape)
# for a, b in zip(rolled_data[0,100-16,100-16,0,:,:,1],range(100)):
#     print(b,a)
#
# # train_data[:,3] = np.arange(155)
# # for i in range(220):
# #     train_data[i,0] = i
# #     print(i)
# # for i in range(240):
# #     train_data[:,1,i] = i
# #     train_data[:,2,:,i] = i
# #     print(i)
# # for i in range(155):
# #     train_data[:,3,:,:,i]=i
# #     print(i)
#
#
# lblidx = np.load(HDD_READ_PATH + "labelidx2.npy")
# print(lblidx[np.argwhere(lblidx[:,2]>218)])
# print(lblidx[np.argwhere(lblidx[:,1]>218)])
# pre_mean_roll = np.rollaxis(np.rollaxis(train_data, 0, -1), 0, -1)
# pre_mean_roll = rolling_window(pre_mean_roll, (11, 11))
# print(pre_mean_roll.shape)
# # n = 0
# # h =-1
# # w=-1
# # d=70
# # print(pre_mean_roll[h,w,n,:,d][1:3])
# pre_mean_roll = rolling_window(pre_mean_roll, (PATCH[0], PATCH[1]))
# pre_mean_roll = np.rollaxis(pre_mean_roll, 8, 3)
# pre_mean_roll = np.rollaxis(pre_mean_roll, 8, 3)
# pre_mean_roll = np.rollaxis(pre_mean_roll, 6, 3)
# pre_mean_roll = np.rollaxis(pre_mean_roll, 2, 0)
# print(pre_mean_roll.shape)
# np.memmap("/home/wltjr1007/PycharmProjects/CNNforBRATS/output/test_this2.npy", dtype=np.uint8, mode="w+",
#           shape=(198, 198, 33, 33, 2))[:] = np.mean(pre_mean_roll[0, :, :, 0, :, :, 1:3], axis=(-1, -2))










# # train_PM_data = np.memmap(HDD_READ_PATH+"h_train_2_out.dat", shape=(220,NUM_CHANNELS[1], SHAPE[1], SHAPE[2], SHAPE[3]), dtype=np.float32, mode = "r")
# #
# # with open(os.path.join(HDD_READ_PATH, "labelidx2.txt"), 'r') as f:
# #     labelid2 = pickle.load(f)
# # idx = np.empty((0,4), dtype=np.uint8)
# # for i in range(220):
# #     for j in range(5):
# #         curidx = labelid2[i,j]
# #         tempidx = np.empty((curidx.shape[0], 4), dtype=np.uint8)
# #         tempidx[:,0] = i
# #         tempidx[:,1:] = curidx
# #         idx = np.append(idx, tempidx, axis=0)
# # print(idx.shape)
# # idx = np.sort(idx.view('u1,u1,u1,u1'), order=["f1","f2","f3"], axis=0).view(np.uint8)
# #
# # train_mean_data = rolling_window(train_PM_data, (11,11))
# #
# # for i in range(0,2001353,128):
# #     curidx = idx[i:i+128]
# #     a = train_PM_data[curidx[:,0],:,curidx[:,1],curidx[:,2],curidx[:,3]]
#
# def extract_PM_window(dataset, is_mean=None):
#     train_data = np.memmap(os.path.join(SSD_READ_PATH, dataset+"_train_2_out.dat"), dtype=np.float32, mode="r").reshape(-1,
#                                                                                                                  NUM_CHANNELS[
#                                                                                                                      1],
#                                                                                                                  SHAPE[
#                                                                                                                      1],
#                                                                                                                  SHAPE[
#                                                                                                                      2],
#                                                                                                                  SHAPE[
#                                                                                                                      3])
#     lblidx = np.load(HDD_READ_PATH+"labelidx2.npy")
#     extract_size = lblidx.shape[0]
#     if is_mean is not None:
#         mean_padded_idx = lblidx-[0,(PATCH[0]+is_mean[0])/2, (PATCH[1]+is_mean[1])/2,0]
#
#         rolled_data = np.rollaxis(np.rollaxis(train_data, 0, -1), 0, -1)
#         rolled_data = rolling_window(rolled_data, (PATCH[0], PATCH[1]))
#         rolled_data = np.rollaxis(np.rollaxis(rolled_data, 2, 0), 3, 7)
#
#         pre_mean_roll = np.rollaxis(np.rollaxis(train_data, 0, -1), 0, -1)
#         pre_mean_roll = rolling_window(rolling_window(pre_mean_roll, is_mean), (PATCH[0], PATCH[1]))
#         pre_mean_roll = np.rollaxis(pre_mean_roll, 8,3)
#         pre_mean_roll = np.rollaxis(pre_mean_roll, 8,3)
#         pre_mean_roll = np.rollaxis(pre_mean_roll, 6,3)
#         pre_mean_roll = np.rollaxis(pre_mean_roll, 2,0)
#         print(rolled_data.shape)
#         print(pre_mean_roll.shape)
#
#         for curcnt in range(220):
#             w = 100
#             h = 100
#             d= 70
#             bbb = np.empty((33,33,9))
#             bbb[...,:NUM_CHANNELS[0]] = np.mean(pre_mean_roll[curcnt,w+21,h+21,d,:,:,:NUM_CHANNELS[0]], axis=(-1,-2))
#             bbb[...,NUM_CHANNELS[0]:] =
#             for i in range(9):
#                 ax = plt.subplot(2,9,i+1)
#                 ax.imshow(rolled_data[curcnt,w+16,h+16,d,:,:,i])
#                 ax2 = plt.subplot(2,9,i+10)
#                 ax2.imshow(bbb[...,i])
#             plt.show()
#
#
# if __name__=="__main__":
#     extract_PM_window("h", (11,11))
